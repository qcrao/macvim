gotool
======

A library of some of the utility functions provided by (but not exported) by cmd/go
