# Regression tests for gometalinter

These tests run specific linters through gometalinter and verify that they
output what we expect from a particular piece of source code.
